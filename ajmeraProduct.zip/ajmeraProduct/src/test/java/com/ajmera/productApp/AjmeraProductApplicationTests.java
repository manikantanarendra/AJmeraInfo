package com.ajmera.productApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjmeraProductApplicationTests {

	@Test
	void contextLoads() {
	}

}

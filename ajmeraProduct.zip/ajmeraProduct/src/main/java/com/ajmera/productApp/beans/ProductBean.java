package com.ajmera.productApp.beans;

import java.io.Serializable;

import com.ajmera.productApp.entities.Product;

public class ProductBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 12346L;
	private Product product;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ProductBean(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductBean [product=" + product + "]";
	}

	public ProductBean() {
		
	}
	
	
	
}

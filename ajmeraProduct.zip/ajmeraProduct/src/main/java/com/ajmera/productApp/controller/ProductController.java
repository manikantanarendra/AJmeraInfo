package com.ajmera.productApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ajmera.productApp.beans.ProductBean;
import com.ajmera.productApp.entities.Product;
import com.ajmera.productApp.repositories.ProductRepository;

@RestController
public class ProductController {

	@Autowired
	private ProductRepository productRepository;

	@PostMapping("/insertProduct")
	public Product insertProduct(@RequestBody ProductBean productBean) {
		return productRepository.save(productBean.getProduct());

	}
	
	@GetMapping("/getProducts")
	public List<Product> findAll()
	{
		return productRepository.findAll(); 
	}

}

package com.ajmera.productApp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ajmera.productApp.entities.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

}

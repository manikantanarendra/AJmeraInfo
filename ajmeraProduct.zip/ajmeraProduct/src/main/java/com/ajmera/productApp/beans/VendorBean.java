package com.ajmera.productApp.beans;

import com.ajmera.productApp.entities.Vendor;

public class VendorBean {
	
	private Vendor vendor;

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	
	

}

package com.ajmera.productApp.beans;

import com.ajmera.productApp.entities.Inventory;

public class InventoryBean {

	private Inventory inventory;

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	
	
}

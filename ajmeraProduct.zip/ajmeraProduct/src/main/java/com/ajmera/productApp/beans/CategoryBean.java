package com.ajmera.productApp.beans;

import com.ajmera.productApp.entities.Category;

public class CategoryBean {

	
	private Category category;

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	
}

package com.ajmera.productApp.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Product {
	
	@Id
	private int pid;
	private String productImage;
	private String productName;
	private Date insertedTimestamp;
	private Date updatedTimestamp;
	
	@OneToMany(targetEntity = Category.class,cascade = CascadeType.ALL)
	@JoinColumn(name="pc_fk",referencedColumnName = "pid")
	private List<Category> categories;
	
	@OneToMany(targetEntity = Inventory.class,cascade = CascadeType.ALL)
	@JoinColumn(name="pi_fk",referencedColumnName = "pid")
	private List<Inventory> inventories;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getInsertedTimestamp() {
		return insertedTimestamp;
	}
	public void setInsertedTimestamp(Date insertedTimestamp) {
		this.insertedTimestamp = insertedTimestamp;
	}
	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}
	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
	public List<Category> getCategories() {
		return categories;
	}
	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
	public List<Inventory> getInventories() {
		return inventories;
	}
	public void setInventories(List<Inventory> inventories) {
		this.inventories = inventories;
	}
	
	
	



	
	
}
